# Go Tour

The actual web pages for
“A Tour of Go” moved to [golang.org/x/website](https://golang.org/x/website).

This repo still holds the supporting packages like
[golang.org/x/tour/pic](https://golang.org/x/tour/pic).
